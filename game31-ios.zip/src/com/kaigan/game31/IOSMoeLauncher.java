package com.kaigan.game31;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.LifecycleListener;
import com.badlogic.gdx.backends.iosmoe.IOSApplication;
import com.badlogic.gdx.backends.iosmoe.IOSApplicationConfiguration;

import org.moe.binding.crashlytics.Answers;
import org.moe.binding.crashlytics.CLSStackFrame;
import org.moe.binding.crashlytics.Crashlytics;
import org.moe.binding.fabric.Fabric;
import org.moe.binding.ironsource.ISIntegrationHelper;
import org.moe.binding.ironsource.ISPlacementInfo;
import org.moe.binding.ironsource.IronSource;
import org.moe.binding.ironsource.protocol.ISInterstitialDelegate;
import org.moe.binding.ironsource.protocol.ISOfferwallDelegate;
import org.moe.binding.ironsource.protocol.ISRewardedVideoDelegate;
import org.moe.natj.general.Pointer;
import org.moe.natj.general.ptr.BytePtr;
import org.moe.natj.general.ptr.impl.PtrFactory;

import com.badlogic.gdx.backends.iosmoe.objectal.OALAudioSession;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.Array;

import java.io.PrintWriter;
import java.io.StringWriter;

import apple.coregraphics.struct.CGRect;
import apple.foundation.NSArray;
import apple.foundation.NSData;
import apple.foundation.NSDate;
import apple.foundation.NSDictionary;
import apple.foundation.NSError;
import apple.foundation.NSMutableArray;
import apple.foundation.NSMutableDictionary;
import apple.foundation.NSNumber;
import apple.foundation.NSString;
import apple.foundation.NSURL;
import apple.gamekit.GKAchievement;
import apple.gamekit.GKGameCenterViewController;
import apple.gamekit.GKLocalPlayer;
import apple.gamekit.GKSavedGame;
import apple.gamekit.enums.GKGameCenterViewControllerState;
import apple.glkit.enums.GLKViewDrawableDepthFormat;
import apple.storekit.SKPaymentTransaction;
import apple.storekit.SKProduct;
import apple.storekit.SKStoreProductViewController;
import apple.storekit.SKStoreReviewController;
import apple.storekit.c.StoreKit;
import apple.storekit.protocol.SKStoreProductViewControllerDelegate;
import apple.uikit.UIAlertAction;
import apple.uikit.UIAlertController;
import apple.uikit.UIApplication;
import apple.uikit.UIScreen;
import apple.uikit.UIViewController;
import apple.uikit.c.UIKit;
import apple.uikit.enums.UIAlertActionStyle;
import apple.uikit.enums.UIAlertControllerStyle;
import apple.uikit.struct.UIEdgeInsets;
import game31.Game;
import game31.Globals;
import game31.VoiceProfile;
import sengine.Sys;
import sengine.graphics2d.Fonts;
import sengine.graphics2d.jheora.TheoraMaterial;
import sengine.mass.MassFile;

public class IOSMoeLauncher extends IOSApplication.Delegate implements Game.PlatformInterface {
    private static final String TAG = "IOSMoeLauncher";

    private static final String PREF_FILE = "Save";
    private static final String PREF_TIME = "timestamp";

    public static int fontDoubleResolutionThreshold = 1500;


    private static String printStackTrace(Throwable e) {
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }


    private static class IOSUncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {

        private Thread.UncaughtExceptionHandler _defaultHandler;

        public IOSUncaughtExceptionHandler() {
            this._defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        }

        public void uncaughtException(Thread t, Throwable e) {
            System.out.print("Uncaught exception at " + t + "\n" + printStackTrace(e));

            NSMutableArray<CLSStackFrame> stack = (NSMutableArray<CLSStackFrame>)NSMutableArray.alloc().init();
            for (StackTraceElement element : e.getStackTrace()) {
                CLSStackFrame frame = CLSStackFrame.alloc().init();
                frame.setFileName(element.getFileName());
                frame.setLineNumber(element.getLineNumber());
                frame.setSymbol(element.getClassName() + "." + element.getMethodName());
                stack.add(frame);
            }
            org.moe.binding.crashlytics.c.Crashlytics.CLSLog(printStackTrace(e));
            Crashlytics.sharedInstance().recordCustomExceptionNameReasonFrameArray(e.getClass().getName(), e.getMessage(), stack);

            this._defaultHandler.uncaughtException(t, e);
        }
    }


    protected IOSMoeLauncher(Pointer peer) {
        super(peer);
    }

    private IOSApplication application;

    // GameKit
    private UIViewController gamekitAuthView;
    private boolean isLoggedIn = false;
    private boolean hasDoneLogin = false;

    static {
        // To preload ObjC objects
        try {
            Class.forName(GKSavedGame.class.getName());

            // Fix NatJ runtime class initialization order for binding classes.
//            Class.forName(SKProduct.class.getName());
//            Class.forName(SKPaymentTransaction.class.getName());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Initialization failed", e);
        }
    }


    @Override
    protected IOSApplication createApplication() {
        // Create game
        IOSApplicationConfiguration config = new IOSApplicationConfiguration();

        Game game = new Game(this);

        config.orientationLandscape = false;
        config.orientationPortrait = true;

        config.depthFormat = GLKViewDrawableDepthFormat.FormatNone;

        config.useAccelerometer = false;
        config.useCompass = false;

        TheoraMaterial.MAX_FORWARD_FRAMES = 1;

        application = new IOSApplication(game.applicationListener, config);
        return application;
    }


    @Override
    public boolean applicationDidFinishLaunchingWithOptions(UIApplication application, NSDictionary<?, ?> launchOptions) {
        // Crashlytics
        Fabric.with(NSArray.arrayWithObjects(Crashlytics.alloc().init(), Answers.alloc().init(), null));
        Thread.setDefaultUncaughtExceptionHandler(new IOSUncaughtExceptionHandler());

        return super.applicationDidFinishLaunchingWithOptions(application, launchOptions);
    }


    public static void main(String[] argv) {
        UIKit.UIApplicationMain(0, null, null, IOSMoeLauncher.class.getName());
    }

    @Override
    public void reportLog(String source, String text) {
        org.moe.binding.crashlytics.c.Crashlytics.CLSLog(source + ": " + text);
        System.out.print(source + ": " + text);
    }

    @Override
    public void reportLog(String source, String text, Throwable exception) {
        org.moe.binding.crashlytics.c.Crashlytics.CLSLog(source + ": " + text + "\n" + printStackTrace(exception));
        System.out.print(source + ": " + text + "\n" + printStackTrace(exception));
    }

    @Override
    public void reportLogDebug(String source, String text) {
        org.moe.binding.crashlytics.c.Crashlytics.CLSLog(source + ": " + text);
        System.out.print(source + ": " + text);
    }

    @Override
    public void reportLogDebug(String source, String text, Throwable exception) {
        org.moe.binding.crashlytics.c.Crashlytics.CLSLog(source + ": " + text + "\n" + printStackTrace(exception));
        System.out.print(source + ": " + text + "\n" + printStackTrace(exception));
    }

    @Override
    public void reportLogError(String source, String text) {
        org.moe.binding.crashlytics.c.Crashlytics.CLSLog(source + ": " + text);
        System.out.print(source + ": " + text);
    }

    @Override
    public void reportLogError(String source, String text, Throwable exception) {
        org.moe.binding.crashlytics.c.Crashlytics.CLSLog(source + ": " + text + "\n" + printStackTrace(exception));
        System.out.print(source + ": " + text + "\n" + printStackTrace(exception));
    }
    @Override
    public VoiceProfile createTextVoice(String path) {
        throw new RuntimeException("Not supported, desktop version only");
    }



    @Override
    public void linkGameData() {
        // Determine screen resolution
        CGRect rect = UIScreen.mainScreen().bounds();
        double scale = UIScreen.mainScreen().scale();
        long height = Math.round(rect.size().height() * scale);

        // Double the resolution of fonts if retina and has a high resolution
        if(height >= fontDoubleResolutionThreshold)
            Fonts.resolutionMultiplier = 2;

        // Get safe area insets
        try {
            UIEdgeInsets safeAreaInsets = application.getUIWindow().safeAreaInsets();
            double topInset = safeAreaInsets.top();
            double bottomInset = safeAreaInsets.bottom();
            Globals.topSafeAreaInset = (int) Math.round(topInset * scale);
            Globals.bottomSafeAreaInset = (int) Math.round(bottomInset * scale);
        } catch (Throwable e) {
            reportLogError(TAG, "Unable to get safe area insets", e);
            // Probably not updated to iOS 11
            Globals.topSafeAreaInset = 0;
            Globals.bottomSafeAreaInset = 0;
        }


        // IronSource
        IronSource.initWithAppKey("7b5903f5");
        IronSource.shouldTrackReachability(true);
        IronSource.setRewardedVideoDelegate(new ISRewardedVideoDelegate() {
            @Override
            public void didClickRewardedVideo(ISPlacementInfo placementInfo) {

            }

            @Override
            public void didReceiveRewardForPlacement(ISPlacementInfo placementInfo) {
                try {
                    final int credits = placementInfo.rewardAmount().intValue();
                    reportLog(TAG, "Received rewarded video credits: " + credits);
                    if(credits > 0) {
                        Globals.grid.postMessage(new Runnable() {
                            @Override
                            public void run() {
                                Globals.grid.flapeeBirdApp.queueReward(credits);
                            }
                        });
                    }
                } catch (Throwable e) {
                    reportLogError(TAG, "Failed to process rewarded video credits", e);
                }
            }

            @Override
            public void rewardedVideoDidClose() {
                // This is needed for OAL not resuming after video closes
                reportLogDebug(TAG, "Ending OAL interruption");
                OALAudioSession.sharedInstance().forceEndInterruption();

                // Show reward
                Globals.grid.postMessage(new Runnable() {
                    @Override
                    public void run() {
                        if(Globals.grid.flapeeBirdApp.queuedReward() > 0)
                            Globals.grid.flapeeBirdApp.showRewardMenu();
                        else
                            Globals.grid.flapeeBirdApp.showMenu(false);
                    }
                });
            }

            @Override
            public void rewardedVideoDidEnd() {

            }

            @Override
            public void rewardedVideoDidFailToShowWithError(NSError error) {

            }

            @Override
            public void rewardedVideoDidOpen() {

            }

            @Override
            public void rewardedVideoDidStart() {

            }

            @Override
            public void rewardedVideoHasChangedAvailability(boolean available) {

            }
        });
        IronSource.setInterstitialDelegate(new ISInterstitialDelegate() {
            @Override
            public void didClickInterstitial() {

            }

            @Override
            public void interstitialDidClose() {
                // This is needed for OAL not resuming after video closes
                reportLogDebug(TAG, "Ending OAL interruption");
                OALAudioSession.sharedInstance().forceEndInterruption();
                // Load another
                IronSource.loadInterstitial();

                // Show menu
                Globals.grid.postMessage(new Runnable() {
                    @Override
                    public void run() {
                        Globals.grid.flapeeBirdApp.showMenu(true);
                    }
                });
            }

            @Override
            public void interstitialDidFailToLoadWithError(NSError error) {

            }

            @Override
            public void interstitialDidFailToShowWithError(NSError error) {

            }

            @Override
            public void interstitialDidLoad() {

            }

            @Override
            public void interstitialDidOpen() {

            }

            @Override
            public void interstitialDidShow() {

            }
        });
        IronSource.setOfferwallDelegate(new ISOfferwallDelegate() {
            @Override
            public void didFailToReceiveOfferwallCreditsWithError(NSError error) {

            }

            @Override
            public boolean didReceiveOfferwallCredits(NSDictionary<?, ?> creditInfo) {
                int credits = 0;
                try {
                    String text = (String) creditInfo.get("credits");
                    String totalCreditsFlagText = (String) creditInfo.get("totalCreditsFlag");
                    reportLog(TAG, "Received offerwall credits: " + text + " " + totalCreditsFlagText);
                    boolean totalCreditsFlag = totalCreditsFlagText.equalsIgnoreCase("YES");
                    if(totalCreditsFlag)
                        credits = 0;
                    else
                        credits = Integer.parseInt(text);
                } catch (Throwable e) {
                    reportLogError(TAG, "Failed to process offerwall credits", e);
                }

                final int creditsFinal = credits;

                Globals.grid.postMessage(new Runnable() {
                    @Override
                    public void run() {
                        if(creditsFinal > 0) {
                            Globals.grid.flapeeBirdApp.queueReward(creditsFinal);
                            Globals.grid.flapeeBirdApp.showRewardMenu();
                        }
                        else
                            Globals.grid.flapeeBirdApp.showMenu(true);
                    }
                });

                // Absorb any
                return true;
            }

            @Override
            public void offerwallDidClose() {
                // This is needed for OAL not resuming after video closes
                reportLogDebug(TAG, "Ending OAL interruption");
                OALAudioSession.sharedInstance().forceEndInterruption();

                // Process offerwall credits
                IronSource.offerwallCredits();
            }

            @Override
            public void offerwallDidFailToShowWithError(NSError error) {

            }

            @Override
            public void offerwallDidShow() {

            }

            @Override
            public void offerwallHasChangedAvailability(boolean available) {

            }
        });
        IronSource.loadInterstitial();

        // Validate (remove on release)
//        ISIntegrationHelper.validateIntegration();

        // Check if app version has expired
        new Runnable() {
            @Override
            public void run() {
                final Runnable repeat = this;

                if(System.currentTimeMillis() > 1540008265000L) {
                    // Inform need to login via settings
                    UIAlertController view = UIAlertController.alertControllerWithTitleMessagePreferredStyle(
                            "Update Required",
                            "A new update is required to continue. Please download now.",
                            UIAlertControllerStyle.Alert
                    );

                    UIAlertAction yesAction = UIAlertAction.actionWithTitleStyleHandler("Update", UIAlertActionStyle.Default, action -> {
                        SKStoreProductViewController productView = SKStoreProductViewController.alloc().init();

                        NSDictionary dictionary = NSDictionary.dictionaryWithObjectForKey("1436716278", StoreKit.SKStoreProductParameterITunesItemIdentifier());

                        productView.loadProductWithParametersCompletionBlock(dictionary, (arg0, arg1) -> {
                            // nothing
                        });

                        productView.setDelegate(new SKStoreProductViewControllerDelegate() {
                            @Override
                            public void productViewControllerDidFinish(SKStoreProductViewController viewController) {
                                viewController.dismissViewControllerAnimatedCompletion(true, null);
                                // Show again
                                repeat.run();
                            }
                        });

                        application.getUIViewController().presentViewControllerAnimatedCompletion(productView, true, null);

                    });

                    view.addAction(yesAction);

                    application.getUIViewController().presentViewControllerAnimatedCompletion(view, true, null);
                }
            }

        }.run();


        // nothing to link
    }


    @Override
    public void prepareSaveGame() {
        // Initialize GameKit
        Sys.info(TAG, "Authenticating GameCenter");
        GKLocalPlayer localPlayer = GKLocalPlayer.localPlayer();
        localPlayer.setAuthenticateHandler((viewController, error) -> {
            Sys.system.minTimeInterval = 0;
            isLoggedIn = GKLocalPlayer.localPlayer().isAuthenticated();
            Sys.info(TAG, "GameCenter authenticated: " + isLoggedIn + " " + hasDoneLogin + " " + viewController);
            if(!isLoggedIn) {
                // Maybe need to show login controller
                gamekitAuthView = viewController;
                informDoneLogin();
                return;
            }
            // Else has logged in, check save game
            gamekitAuthView = null;
            final FileHandle fileHandle = Gdx.files.local(Globals.SAVE_FILENAME);
            if(fileHandle.exists()) {
                Sys.info(TAG, "Local save found");
                // Save already in local, just use that, but continue with fetching cloud save
                informDoneLogin();
            }
            else
                Sys.info(TAG, "Local save not found, fetching cloud saves");
            // Else fetch saved game from cloud
            localPlayer.fetchSavedGamesWithCompletionHandler((array, error1) -> {
                if(array == null) {
                    Sys.error(TAG, "No save games fetched " + error1);
                    informDoneLogin();
                    return;
                }
                // Else check if there are save conflicts
                GKSavedGame bestSave = null;
                Array<GKSavedGame> conflicts = new Array<>(GKSavedGame.class);
                for(GKSavedGame save : array) {
                    if(save.name().equals(Globals.SAVE_FILENAME)) {
                        if(bestSave != null) {
                            // Check date
                            double bestSaveTimestamp = bestSave.modificationDate().timeIntervalSince1970();
                            double saveTimestamp = save.modificationDate().timeIntervalSince1970();
                            if(saveTimestamp > bestSaveTimestamp) {
                                // This save is newer, use this one
                                conflicts.add(bestSave);
                                bestSave = save;
                            }
                            else {
                                // Else best save is newer, just add this as a conflict
                                conflicts.add(save);
                            }
                        }
                        else
                            bestSave = save;        // First save encountered
                    }
                }
                // Load best save
                if(bestSave == null) {
                    Sys.info(TAG, "Save game not found in cloud");
                    // No save found
                    informDoneLogin();
                    return;
                }

                // Get local timestamp
                long localTimestamp = Gdx.app.getPreferences(PREF_FILE).getLong(PREF_TIME, Long.MIN_VALUE);
                long cloudTimestamp = (long) (bestSave.modificationDate().timeIntervalSince1970() * 1000);
                if(localTimestamp >= cloudTimestamp) {
                    // Local timestamp is newer, so keep using local, no need to update
                    informDoneLogin();
                    return;
                }

                // Else save found, read
                bestSave.loadDataWithCompletionHandler((data, error2) -> {
                    // Read data to bytes
                    int saveSize = (int) data.length();
                    if(saveSize <= 0) {
                        Sys.error(TAG, "Unable to retrieve save data from cloud");
                        // No save data
                        informDoneLogin();
                        return;
                    }

                    // Copy to native buffer
                    BytePtr bytePtr = PtrFactory.newGuardedByteArray(saveSize + 1);     // TODO: bug in BytePtr, posted on GitHub issues
                    data.getBytesLength(bytePtr, saveSize);

                    // Copy to java buffer
                    byte[] bytes = new byte[saveSize];
                    bytePtr.copyTo(bytes, saveSize);

                    // Write to save file
                    updateSaveGame(bytes, cloudTimestamp);
                    // Update timestamp


                    // Resolve conflicts before proceeding
                    if(conflicts.size > 0) {
                        Sys.error(TAG, "Resolving " + conflicts.size + " save conflicts on cloud");
                        GKSavedGame first = conflicts.removeIndex(0);       // arrayWithObjects require first element
                        conflicts.add(null);            // arrayWithObjects require null termination
                        GKSavedGame[] conflictsArray = conflicts.toArray();
                        NSArray<GKSavedGame> nsArray = (NSArray<GKSavedGame>) NSArray.arrayWithObjects(first, (Object[]) conflictsArray);
                        localPlayer.resolveConflictingSavedGamesWithDataCompletionHandler(nsArray, data, null);     // no need to wait for completion
                    }

                    // Done
                    informDoneLogin();
                });

            });

        });
    }

    private void informDoneLogin() {
        if(hasDoneLogin)
            return;     // Already done login
        hasDoneLogin = true;
        // Inform main menu has done
        Globals.grid.mainMenu.doneLogin(isLoggedIn, existsSaveGame());
    }

    // Save methods
    @Override
    public synchronized boolean existsSaveGame() {
        return Gdx.files.local(Globals.SAVE_FILENAME).exists();
    }

    @Override
    public synchronized void writeSaveGame(MassFile save) {
        FileHandle fileHandle = Gdx.files.local(Globals.SAVE_FILENAME);
        save.save(fileHandle);

        try {
            // Get local time
            long localTimestamp = (long) (NSDate.date().timeIntervalSince1970() * 1000);
            Gdx.app.getPreferences(PREF_FILE).putLong(PREF_TIME, localTimestamp).flush();

            // Save to cloud if logged in
            GKLocalPlayer localPlayer = GKLocalPlayer.localPlayer();
            if (localPlayer.isAuthenticated()) {
                // Submit to cloud
                byte[] saveData = fileHandle.readBytes();
                BytePtr bytePtr = PtrFactory.newByteArray(saveData);
                NSData data = NSData.dataWithBytesLength(bytePtr, saveData.length);
                localPlayer.saveGameDataWithNameCompletionHandler(data, Globals.SAVE_FILENAME, (cloudSave, error) -> {
                    try {
                        long cloudTimestamp = (long) (cloudSave.modificationDate().timeIntervalSince1970() * 1000);
                        Gdx.app.getPreferences(PREF_FILE).putLong(PREF_TIME, cloudTimestamp).flush();
                        Sys.info(TAG, "Uploaded save to cloud");
                    } catch(Throwable e) {
                        Sys.error(TAG, "Unable to write save game", e);
                    }
                });
            }
        } catch (Throwable e) {
            Sys.error(TAG, "Unable to write save game", e);
        }

    }

    @Override
    public synchronized MassFile readSaveGame() {
        FileHandle fileHandle = Gdx.files.local(Globals.SAVE_FILENAME);
        MassFile save = new MassFile();
        save.load(fileHandle);

        return save;
    }

    @Override
    public synchronized void deleteSaveGame() {
        Gdx.files.local(Globals.SAVE_FILENAME).delete();

        // Update cloud if logged in
        try {
            GKLocalPlayer localPlayer = GKLocalPlayer.localPlayer();
            if (localPlayer.isAuthenticated()) {
                localPlayer.deleteSavedGamesWithNameCompletionHandler(Globals.SAVE_FILENAME, error -> Sys.info(TAG, "Deleted save on cloud"));
            }

            Gdx.app.getPreferences(PREF_FILE).remove(PREF_TIME);
        } catch (Throwable e) {
            Sys.error(TAG, "Unable to delete save game", e);
        }
    }

    private synchronized void updateSaveGame(byte[] saveData, long timestamp) {
        FileHandle fileHandle = Gdx.files.local(Globals.SAVE_FILENAME);
        fileHandle.writeBytes(saveData, false);

        Gdx.app.getPreferences(PREF_FILE).putLong(PREF_TIME, timestamp).flush();

        Sys.info(TAG, "Updated save game with cloud");
    }

    @Override
    public boolean showGameCenter() {
        return true;
    }

    @Override
    public boolean promptGameCenterLogin() {
        return !isLoggedIn && gamekitAuthView != null;
    }

    @Override
    public void openGameCenter() {
        if(GKLocalPlayer.localPlayer().isAuthenticated()) {
            Sys.info(TAG, "Showing GameCenter achievements view");
            Sys.system.minTimeInterval = 1f;        // 1 fps
            GKGameCenterViewController view = GKGameCenterViewController.alloc().init();
            view.setViewState(GKGameCenterViewControllerState.Achievements);
            view.setGameCenterDelegate(gameCenterViewController -> {
                Sys.info(TAG, "Closing GameCenter achievements view");
                Sys.system.minTimeInterval = 0;
                view.dismissViewControllerAnimatedCompletion(true, null);
            });
            application.getUIViewController().presentViewControllerAnimatedCompletion(view, true, null);
        }
        else {
            // Inform need to login via settings
            UIAlertController view = UIAlertController.alertControllerWithTitleMessagePreferredStyle(
                    "GameCenter Disabled",
                    "You need to activate GameCenter at Settings->GameCenter. Would you like to do it now?",
                    UIAlertControllerStyle.Alert
            );

            UIAlertAction yesAction = UIAlertAction.actionWithTitleStyleHandler("Yes", UIAlertActionStyle.Default, action -> {
                UIApplication.sharedApplication().openURL(NSURL.URLWithString(UIKit.UIApplicationOpenSettingsURLString()));
            });

            UIAlertAction noAction = UIAlertAction.actionWithTitleStyleHandler("No", UIAlertActionStyle.Cancel, null);

            view.addAction(yesAction);
            view.addAction(noAction);

            application.getUIViewController().presentViewControllerAnimatedCompletion(view, true, null);
        }
    }

    @Override
    public void loginGameCenter() {
        // Show game center if needed
        if(gamekitAuthView != null) {
            Sys.info(TAG, "Showing GameCenter login view");
            Sys.system.minTimeInterval = 1f;        // 1 fps
            hasDoneLogin = false;
            application.getUIViewController().presentViewControllerAnimatedCompletion(gamekitAuthView, true, null);
            gamekitAuthView = null;
        }
    }

    @Override
    public void unlockAchievement(Globals.Achievement achievement) {
        String id = achievement.name();
        try {
            if (!GKLocalPlayer.localPlayer().isAuthenticated()) {
                Sys.error(TAG, "Unable to unlock achievement " + id + " because player was not authenticated");
                return;
            }
            // ELse can unlock
            GKAchievement ach = GKAchievement.alloc().initWithIdentifier(id);
            if (ach.percentComplete() >= 100) {
                // Already unlocked
                Sys.info(TAG, "Achievement " + achievement + " already unlocked by player");
                return;
            }
            ach.setPercentComplete(100);
            ach.setShowsCompletionBanner(true);
            NSArray<GKAchievement> nsArray = (NSArray<GKAchievement>) NSArray.arrayWithObjects(ach, (Object) null);
            GKAchievement.reportAchievementsWithCompletionHandler(nsArray, error -> {
                if (error != null) {
                    Sys.error(TAG, "Unable to unlock achievement " + id + ", reason: " + error);
                }
            });
            Sys.info(TAG, "Unlocking achievement " + id);
        } catch (Throwable e) {
            Sys.error(TAG, "Unable to unlock achievement " + id, e);
        }
    }

    @Override
    public void processCallbacks() {
        // nothing
    }

    @Override
    public boolean showRewardedVideoAd() {
        if(IronSource.hasRewardedVideo()) {
            reportLog(TAG, "Showing Rewarded Video Ad");
            IronSource.showRewardedVideoWithViewController(application.getUIViewController());
            return true;
        }
        else if(IronSource.hasOfferwall()) {
            reportLog(TAG, "Showing Offerwall Ads");
            IronSource.showOfferwallWithViewController(application.getUIViewController());
            return true;
        }
        else
            return false;
    }

    @Override
    public boolean showInterstitialAd() {
        if(IronSource.hasInterstitial()) {
            reportLog(TAG, "Showing Interstitial Ads");
            IronSource.showInterstitialWithViewController(application.getUIViewController());
            return true;
        }
        else
            return false;
    }

    @Override
    public void openSimulacraAppPage() {
        // Open simulacra appstore page
        SKStoreProductViewController productView = SKStoreProductViewController.alloc().init();

        NSDictionary dictionary = NSDictionary.dictionaryWithObjectForKey("1252035454", StoreKit.SKStoreProductParameterITunesItemIdentifier());

        productView.loadProductWithParametersCompletionBlock(dictionary, (arg0, arg1) -> {
            // nothing
        });

        productView.setDelegate(new SKStoreProductViewControllerDelegate() {
            @Override
            public void productViewControllerDidFinish(SKStoreProductViewController viewController) {
                viewController.dismissViewControllerAnimatedCompletion(true, null);
            }
        });

        application.getUIViewController().presentViewControllerAnimatedCompletion(productView, true, null);
    }

    @Override
    public void analyticsStartLevel(String name) {
        try {
            Answers.logLevelStartCustomAttributes(name, null);
        } catch (Throwable e) {
            reportLogError(TAG, "analyticsStartLevel failed: " + name, e);
        }
    }

    @Override
    public void analyticsEndLevel(String name, int score, boolean success) {
        try {
            if (score == -1)
                Answers.logLevelEndScoreSuccessCustomAttributes(name, null, null, null);
            else
                Answers.logLevelEndScoreSuccessCustomAttributes(name, NSNumber.numberWithInt(score), NSNumber.numberWithBool(success), null);
        } catch (Throwable e) {
            reportLogError(TAG, "analyticsEndLevel failed: " + name + " " + score + " " + success, e);
        }
    }

    @Override
    public void analyticsEvent(String name) {
        try {
            Answers.logCustomEventWithNameCustomAttributes(name, null);
        } catch (Throwable e) {
            reportLogError(TAG, "analyticsEvent failed: " + name, e);
        }

    }

    @Override
    public void analyticsView(String name, String type, String id) {
        try {
            Answers.logContentViewWithNameContentTypeContentIdCustomAttributes(name, type, id, null);
        } catch (Throwable e) {
            reportLogError(TAG, "analyticsView failed : " + name + " " + type + " " + id);
        }

    }

    @Override
    public void analyticsValue(String name, String field, float value) {
        try {
            NSMutableDictionary<String, Object> attributes = (NSMutableDictionary<String, Object>) NSMutableDictionary.alloc().init();
            attributes.put(field, NSNumber.numberWithFloat(value));
            Answers.logCustomEventWithNameCustomAttributes(name, attributes);
        } catch (Throwable e) {
            reportLogError(TAG, "analyticsValue failed: " + name + " " + field + " " + value, e);
        }
    }

    @Override
    public void analyticsString(String name, String field, String value) {
        try {
            NSMutableDictionary<String, Object> attributes = (NSMutableDictionary<String, Object>) NSMutableDictionary.alloc().init();
            attributes.put(field, value);
            Answers.logCustomEventWithNameCustomAttributes(name, attributes);
        } catch (Throwable e) {
            reportLogError(TAG, "analyticsString failed: " + name + " " + field + " " + value, e);
        }
    }

    @Override
    public void exitGame() {
        // nothing
    }

    @Override
    public void openReviewPage() {
        SKStoreReviewController.requestReview();
    }

    @Override
    public void destroyed() {
        // nothing
    }

    @Override
    public void setWindowed() {
        // nothing
    }
}
