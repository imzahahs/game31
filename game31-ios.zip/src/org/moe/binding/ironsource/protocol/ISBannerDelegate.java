package org.moe.binding.ironsource.protocol;


import apple.foundation.NSError;
import org.moe.binding.ironsource.ISBannerView;
import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.Library;
import org.moe.natj.general.ann.Runtime;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.ann.ObjCProtocolName;
import org.moe.natj.objc.ann.Selector;

@Generated
@Library("IronSource")
@Runtime(ObjCRuntime.class)
@ObjCProtocolName("ISBannerDelegate")
public interface ISBannerDelegate {
	@Generated
	@Selector("bannerDidDismissScreen")
	void bannerDidDismissScreen();

	@Generated
	@Selector("bannerDidFailToLoadWithError:")
	void bannerDidFailToLoadWithError(NSError error);

	@Generated
	@Selector("bannerDidLoad:")
	void bannerDidLoad(ISBannerView bannerView);

	@Generated
	@Selector("bannerWillLeaveApplication")
	void bannerWillLeaveApplication();

	@Generated
	@Selector("bannerWillPresentScreen")
	void bannerWillPresentScreen();

	@Generated
	@Selector("didClickBanner")
	void didClickBanner();
}