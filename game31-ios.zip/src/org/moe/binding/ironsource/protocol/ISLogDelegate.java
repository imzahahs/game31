package org.moe.binding.ironsource.protocol;


import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.Library;
import org.moe.natj.general.ann.Runtime;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.ann.ObjCProtocolName;
import org.moe.natj.objc.ann.Selector;

@Generated
@Library("IronSource")
@Runtime(ObjCRuntime.class)
@ObjCProtocolName("ISLogDelegate")
public interface ISLogDelegate {
	@Generated
	@Selector("sendLog:level:tag:")
	void sendLogLevelTag(String log, int level, int tag);
}