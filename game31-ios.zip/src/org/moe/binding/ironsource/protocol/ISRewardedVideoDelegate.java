package org.moe.binding.ironsource.protocol;


import apple.foundation.NSError;
import org.moe.binding.ironsource.ISPlacementInfo;
import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.Library;
import org.moe.natj.general.ann.Runtime;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.ann.ObjCProtocolName;
import org.moe.natj.objc.ann.Selector;

@Generated
@Library("IronSource")
@Runtime(ObjCRuntime.class)
@ObjCProtocolName("ISRewardedVideoDelegate")
public interface ISRewardedVideoDelegate {
	@Generated
	@Selector("didClickRewardedVideo:")
	void didClickRewardedVideo(ISPlacementInfo placementInfo);

	@Generated
	@Selector("didReceiveRewardForPlacement:")
	void didReceiveRewardForPlacement(ISPlacementInfo placementInfo);

	@Generated
	@Selector("rewardedVideoDidClose")
	void rewardedVideoDidClose();

	@Generated
	@Selector("rewardedVideoDidEnd")
	void rewardedVideoDidEnd();

	@Generated
	@Selector("rewardedVideoDidFailToShowWithError:")
	void rewardedVideoDidFailToShowWithError(NSError error);

	@Generated
	@Selector("rewardedVideoDidOpen")
	void rewardedVideoDidOpen();

	@Generated
	@Selector("rewardedVideoDidStart")
	void rewardedVideoDidStart();

	@Generated
	@Selector("rewardedVideoHasChangedAvailability:")
	void rewardedVideoHasChangedAvailability(boolean available);
}