package org.moe.binding.ironsource.protocol;


import apple.foundation.NSError;
import org.moe.binding.ironsource.ISPlacementInfo;
import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.Library;
import org.moe.natj.general.ann.Runtime;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.ann.ObjCProtocolName;
import org.moe.natj.objc.ann.Selector;

@Generated
@Library("IronSource")
@Runtime(ObjCRuntime.class)
@ObjCProtocolName("ISDemandOnlyRewardedVideoDelegate")
public interface ISDemandOnlyRewardedVideoDelegate {
	@Generated
	@Selector("didClickRewardedVideo:instanceId:")
	void didClickRewardedVideoInstanceId(ISPlacementInfo placementInfo,
			String instanceId);

	@Generated
	@Selector("didReceiveRewardForPlacement:instanceId:")
	void didReceiveRewardForPlacementInstanceId(ISPlacementInfo placementInfo,
			String instanceId);

	@Generated
	@Selector("rewardedVideoDidClose:")
	void rewardedVideoDidClose(String instanceId);

	@Generated
	@Selector("rewardedVideoDidFailToShowWithError:instanceId:")
	void rewardedVideoDidFailToShowWithErrorInstanceId(NSError error,
			String instanceId);

	@Generated
	@Selector("rewardedVideoDidOpen:")
	void rewardedVideoDidOpen(String instanceId);

	@Generated
	@Selector("rewardedVideoHasChangedAvailability:instanceId:")
	void rewardedVideoHasChangedAvailabilityInstanceId(boolean available,
			String instanceId);
}