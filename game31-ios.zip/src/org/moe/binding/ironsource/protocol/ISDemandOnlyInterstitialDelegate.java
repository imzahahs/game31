package org.moe.binding.ironsource.protocol;


import apple.foundation.NSError;
import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.Library;
import org.moe.natj.general.ann.Runtime;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.ann.ObjCProtocolName;
import org.moe.natj.objc.ann.Selector;

@Generated
@Library("IronSource")
@Runtime(ObjCRuntime.class)
@ObjCProtocolName("ISDemandOnlyInterstitialDelegate")
public interface ISDemandOnlyInterstitialDelegate {
	@Generated
	@Selector("didClickInterstitial:")
	void didClickInterstitial(String instanceId);

	@Generated
	@Selector("interstitialDidClose:")
	void interstitialDidClose(String instanceId);

	@Generated
	@Selector("interstitialDidFailToLoadWithError:instanceId:")
	void interstitialDidFailToLoadWithErrorInstanceId(NSError error,
			String instanceId);

	@Generated
	@Selector("interstitialDidFailToShowWithError:instanceId:")
	void interstitialDidFailToShowWithErrorInstanceId(NSError error,
			String instanceId);

	@Generated
	@Selector("interstitialDidLoad:")
	void interstitialDidLoad(String instanceId);

	@Generated
	@Selector("interstitialDidOpen:")
	void interstitialDidOpen(String instanceId);

	@Generated
	@Selector("interstitialDidShow:")
	void interstitialDidShow(String instanceId);
}