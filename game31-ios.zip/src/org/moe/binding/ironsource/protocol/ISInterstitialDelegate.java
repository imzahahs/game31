package org.moe.binding.ironsource.protocol;


import apple.foundation.NSError;
import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.Library;
import org.moe.natj.general.ann.Runtime;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.ann.ObjCProtocolName;
import org.moe.natj.objc.ann.Selector;

@Generated
@Library("IronSource")
@Runtime(ObjCRuntime.class)
@ObjCProtocolName("ISInterstitialDelegate")
public interface ISInterstitialDelegate {
	@Generated
	@Selector("didClickInterstitial")
	void didClickInterstitial();

	@Generated
	@Selector("interstitialDidClose")
	void interstitialDidClose();

	@Generated
	@Selector("interstitialDidFailToLoadWithError:")
	void interstitialDidFailToLoadWithError(NSError error);

	@Generated
	@Selector("interstitialDidFailToShowWithError:")
	void interstitialDidFailToShowWithError(NSError error);

	@Generated
	@Selector("interstitialDidLoad")
	void interstitialDidLoad();

	@Generated
	@Selector("interstitialDidOpen")
	void interstitialDidOpen();

	@Generated
	@Selector("interstitialDidShow")
	void interstitialDidShow();
}