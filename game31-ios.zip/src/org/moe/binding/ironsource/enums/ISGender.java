package org.moe.binding.ironsource.enums;


import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.NInt;

@Generated
public final class ISGender {
	@Generated
	private ISGender() {
	}

	@Generated
	@NInt
	public static final long UNKNOWN = 0x0000000000000000L;
	@Generated
	@NInt
	public static final long MALE = 0x0000000000000001L;
	@Generated
	@NInt
	public static final long FEMALE = 0x0000000000000002L;
}