package org.moe.binding.ironsource.enums;


import org.moe.natj.general.ann.Generated;

@Generated
public final class LogLevelValues {
	@Generated
	private LogLevelValues() {
	}

	@Generated
	public static final int NONE = 0xFFFFFFFF;
	@Generated
	public static final int INTERNAL = 0x00000000;
	@Generated
	public static final int INFO = 0x00000001;
	@Generated
	public static final int WARNING = 0x00000002;
	@Generated
	public static final int ERROR = 0x00000003;
	@Generated
	public static final int CRITICAL = 0x00000004;
}