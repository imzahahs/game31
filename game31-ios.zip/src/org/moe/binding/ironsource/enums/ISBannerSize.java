package org.moe.binding.ironsource.enums;


import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.NUInt;

@Generated
public final class ISBannerSize {
	@Generated
	private ISBannerSize() {
	}

	@Generated
	@NUInt
	public static final long BANNER = 0x0000000000000001L;
	@Generated
	@NUInt
	public static final long LARGE_BANNER = 0x0000000000000002L;
	@Generated
	@NUInt
	public static final long RECTANGLE_BANNER = 0x0000000000000003L;
	@Generated
	@NUInt
	public static final long TABLET_BANNER = 0x0000000000000004L;
	@Generated
	@NUInt
	public static final long SMART = 0x0000000000000005L;
}