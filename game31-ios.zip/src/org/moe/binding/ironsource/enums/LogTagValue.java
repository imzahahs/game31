package org.moe.binding.ironsource.enums;


import org.moe.natj.general.ann.Generated;

@Generated
public final class LogTagValue {
	@Generated
	private LogTagValue() {
	}

	@Generated
	public static final int API = 0x00000000;
	@Generated
	public static final int DELEGATE = 0x00000001;
	@Generated
	public static final int ADAPTER_API = 0x00000002;
	@Generated
	public static final int ADAPTER_DELEGATE = 0x00000003;
	@Generated
	public static final int NETWORK = 0x00000004;
	@Generated
	public static final int NATIVE = 0x00000005;
	@Generated
	public static final int INTERNAL = 0x00000006;
	@Generated
	public static final int EVENT = 0x00000007;
}