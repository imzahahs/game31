package org.moe.binding.ironsource;


import apple.NSObject;
import apple.foundation.NSArray;
import apple.foundation.NSDictionary;
import apple.foundation.NSMethodSignature;
import apple.foundation.NSNumber;
import apple.foundation.NSSet;
import org.moe.natj.c.ann.FunctionPtr;
import org.moe.natj.general.NatJ;
import org.moe.natj.general.Pointer;
import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.Library;
import org.moe.natj.general.ann.Mapped;
import org.moe.natj.general.ann.MappedReturn;
import org.moe.natj.general.ann.NInt;
import org.moe.natj.general.ann.NUInt;
import org.moe.natj.general.ann.Owned;
import org.moe.natj.general.ann.Runtime;
import org.moe.natj.general.ptr.VoidPtr;
import org.moe.natj.objc.Class;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.SEL;
import org.moe.natj.objc.ann.ObjCClassBinding;
import org.moe.natj.objc.ann.Selector;
import org.moe.natj.objc.map.ObjCObjectMapper;

@Generated
@Library("IronSource")
@Runtime(ObjCRuntime.class)
@ObjCClassBinding
public class ISConfigurations extends NSObject {
	static {
		NatJ.register();
	}

	@Generated
	protected ISConfigurations(Pointer peer) {
		super(peer);
	}

	@Generated
	@Selector("accessInstanceVariablesDirectly")
	public static native boolean accessInstanceVariablesDirectly();

	@Generated
	@Selector("adapterTimeOutInSeconds")
	public native NSNumber adapterTimeOutInSeconds();

	@Generated
	@Selector("adaptersDebug")
	public native boolean adaptersDebug();

	@Generated
	@Owned
	@Selector("alloc")
	public static native ISConfigurations alloc();

	@Generated
	@Selector("allocWithZone:")
	@MappedReturn(ObjCObjectMapper.class)
	public static native Object allocWithZone(VoidPtr zone);

	@Generated
	@Selector("appKey")
	public native String appKey();

	@Generated
	@Selector("automaticallyNotifiesObserversForKey:")
	public static native boolean automaticallyNotifiesObserversForKey(String key);

	@Generated
	@Selector("cancelPreviousPerformRequestsWithTarget:")
	public static native void cancelPreviousPerformRequestsWithTarget(
			@Mapped(ObjCObjectMapper.class) Object aTarget);

	@Generated
	@Selector("cancelPreviousPerformRequestsWithTarget:selector:object:")
	public static native void cancelPreviousPerformRequestsWithTargetSelectorObject(
			@Mapped(ObjCObjectMapper.class) Object aTarget, SEL aSelector,
			@Mapped(ObjCObjectMapper.class) Object anArgument);

	@Generated
	@Selector("categorizeType")
	public native String categorizeType();

	@Generated
	@Selector("classFallbacksForKeyedArchiver")
	public static native NSArray<String> classFallbacksForKeyedArchiver();

	@Generated
	@Selector("classForKeyedUnarchiver")
	public static native Class classForKeyedUnarchiver();

	@Generated
	@Deprecated
	@Selector("configurations")
	public static native ISConfigurations configurations();

	@Generated
	@Selector("consent")
	@NInt
	public native long consent();

	@Generated
	@Selector("customSegmentParams")
	public native NSDictionary<?, ?> customSegmentParams();

	@Generated
	@Selector("debugDescription")
	public static native String debugDescription_static();

	@Generated
	@Selector("description")
	public static native String description_static();

	@Generated
	@Selector("dynamicUserId")
	public native String dynamicUserId();

	@Generated
	@Selector("getConfigurations")
	public static native ISConfigurations getConfigurations();

	@Generated
	@Selector("hash")
	@NUInt
	public static native long hash_static();

	@Generated
	@Selector("init")
	public native ISConfigurations init();

	@Generated
	@Selector("instanceMethodForSelector:")
	@FunctionPtr(name = "call_instanceMethodForSelector_ret")
	public static native NSObject.Function_instanceMethodForSelector_ret instanceMethodForSelector(
			SEL aSelector);

	@Generated
	@Selector("instanceMethodSignatureForSelector:")
	public static native NSMethodSignature instanceMethodSignatureForSelector(
			SEL aSelector);

	@Generated
	@Selector("instancesRespondToSelector:")
	public static native boolean instancesRespondToSelector(SEL aSelector);

	@Generated
	@Selector("isSubclassOfClass:")
	public static native boolean isSubclassOfClass(Class aClass);

	@Generated
	@Selector("keyPathsForValuesAffectingValueForKey:")
	public static native NSSet<String> keyPathsForValuesAffectingValueForKey(
			String key);

	@Generated
	@Selector("maxNumOfAdaptersToLoadOnStart")
	public native NSNumber maxNumOfAdaptersToLoadOnStart();

	@Generated
	@Selector("maxVideosPerIteration")
	public native NSNumber maxVideosPerIteration();

	@Generated
	@Selector("mediationSegment")
	public native String mediationSegment();

	@Generated
	@Selector("mediationType")
	public native String mediationType();

	@Generated
	@Owned
	@Selector("new")
	@MappedReturn(ObjCObjectMapper.class)
	public static native Object new_objc();

	@Generated
	@Selector("offerwallCustomParameters")
	public native NSDictionary<?, ?> offerwallCustomParameters();

	@Generated
	@Selector("plugin")
	public native String plugin();

	@Generated
	@Selector("pluginFrameworkVersion")
	public native String pluginFrameworkVersion();

	@Generated
	@Selector("pluginVersion")
	public native String pluginVersion();

	@Generated
	@Selector("resolveClassMethod:")
	public static native boolean resolveClassMethod(SEL sel);

	@Generated
	@Selector("resolveInstanceMethod:")
	public static native boolean resolveInstanceMethod(SEL sel);

	@Generated
	@Selector("rewardedVideoCustomParameters")
	public native NSDictionary<?, ?> rewardedVideoCustomParameters();

	@Generated
	@Selector("rvServerParams")
	public native NSDictionary<?, ?> rvServerParams();

	@Generated
	@Selector("segment")
	public native ISSegment segment();

	@Generated
	@Selector("segmentId")
	public native String segmentId();

	@Generated
	@Selector("serr")
	public native NSNumber serr();

	@Generated
	@Selector("setAdapterTimeOutInSeconds:")
	public native void setAdapterTimeOutInSeconds(NSNumber value);

	@Generated
	@Selector("setAdaptersDebug:")
	public native void setAdaptersDebug(boolean value);

	@Generated
	@Selector("setAppKey:")
	public native void setAppKey(String value);

	@Generated
	@Selector("setCategorizeType:")
	public native void setCategorizeType(String value);

	@Generated
	@Selector("setConsent:")
	public native void setConsent(@NInt long value);

	@Generated
	@Selector("setCustomSegmentParams:")
	public native void setCustomSegmentParams(NSDictionary<?, ?> value);

	@Generated
	@Selector("setDynamicUserId:")
	public native void setDynamicUserId(String value);

	@Generated
	@Selector("setMaxNumOfAdaptersToLoadOnStart:")
	public native void setMaxNumOfAdaptersToLoadOnStart(NSNumber value);

	@Generated
	@Selector("setMaxVideosPerIteration:")
	public native void setMaxVideosPerIteration(NSNumber value);

	@Generated
	@Selector("setMediationSegment:")
	public native void setMediationSegment(String value);

	@Generated
	@Selector("setMediationType:")
	public native void setMediationType(String value);

	@Generated
	@Selector("setOfferwallCustomParameters:")
	public native void setOfferwallCustomParameters(NSDictionary<?, ?> value);

	@Generated
	@Selector("setPlugin:")
	public native void setPlugin(String value);

	@Generated
	@Selector("setPluginFrameworkVersion:")
	public native void setPluginFrameworkVersion(String value);

	@Generated
	@Selector("setPluginVersion:")
	public native void setPluginVersion(String value);

	@Generated
	@Selector("setRewardedVideoCustomParameters:")
	public native void setRewardedVideoCustomParameters(NSDictionary<?, ?> value);

	@Generated
	@Selector("setRvServerParams:")
	public native void setRvServerParams(NSDictionary<?, ?> value);

	@Generated
	@Selector("setSegment:")
	public native void setSegment(ISSegment value);

	@Generated
	@Selector("setSegmentId:")
	public native void setSegmentId(String value);

	@Generated
	@Selector("setSerr:")
	public native void setSerr(NSNumber value);

	@Generated
	@Selector("setTrackReachability:")
	public native void setTrackReachability(boolean value);

	@Generated
	@Selector("setUserAge:")
	public native void setUserAge(@NInt long value);

	@Generated
	@Selector("setUserGender:")
	public native void setUserGender(@NInt long value);

	@Generated
	@Selector("setUserId:")
	public native void setUserId(String value);

	@Generated
	@Selector("setVersion:")
	public native void setVersion(String value);

	@Generated
	@Selector("superclass")
	public static native Class superclass_static();

	@Generated
	@Selector("trackReachability")
	public native boolean trackReachability();

	@Generated
	@Selector("userAge")
	@NInt
	public native long userAge();

	@Generated
	@Selector("userGender")
	@NInt
	public native long userGender();

	@Generated
	@Selector("userId")
	public native String userId();

	@Generated
	@Selector("version")
	public native String version();
}