package org.moe.binding.ironsource;


import apple.NSObject;
import apple.foundation.NSArray;
import apple.foundation.NSDictionary;
import apple.foundation.NSMethodSignature;
import apple.foundation.NSSet;
import apple.uikit.UIViewController;
import org.moe.binding.ironsource.protocol.ISBannerDelegate;
import org.moe.binding.ironsource.protocol.ISDemandOnlyInterstitialDelegate;
import org.moe.binding.ironsource.protocol.ISDemandOnlyRewardedVideoDelegate;
import org.moe.binding.ironsource.protocol.ISInterstitialDelegate;
import org.moe.binding.ironsource.protocol.ISLogDelegate;
import org.moe.binding.ironsource.protocol.ISOfferwallDelegate;
import org.moe.binding.ironsource.protocol.ISRewardedInterstitialDelegate;
import org.moe.binding.ironsource.protocol.ISRewardedVideoDelegate;
import org.moe.binding.ironsource.protocol.ISSegmentDelegate;
import org.moe.natj.c.ann.FunctionPtr;
import org.moe.natj.general.NatJ;
import org.moe.natj.general.Pointer;
import org.moe.natj.general.ann.Generated;
import org.moe.natj.general.ann.Library;
import org.moe.natj.general.ann.Mapped;
import org.moe.natj.general.ann.MappedReturn;
import org.moe.natj.general.ann.NInt;
import org.moe.natj.general.ann.NUInt;
import org.moe.natj.general.ann.Owned;
import org.moe.natj.general.ann.Runtime;
import org.moe.natj.general.ptr.VoidPtr;
import org.moe.natj.objc.Class;
import org.moe.natj.objc.ObjCRuntime;
import org.moe.natj.objc.SEL;
import org.moe.natj.objc.ann.ObjCClassBinding;
import org.moe.natj.objc.ann.Selector;
import org.moe.natj.objc.map.ObjCObjectMapper;

@Generated
@Library("IronSource")
@Runtime(ObjCRuntime.class)
@ObjCClassBinding
public class IronSource extends NSObject {
	static {
		NatJ.register();
	}

	@Generated
	protected IronSource(Pointer peer) {
		super(peer);
	}

	@Generated
	@Selector("accessInstanceVariablesDirectly")
	public static native boolean accessInstanceVariablesDirectly();

	@Generated
	@Selector("advertiserId")
	public static native String advertiserId();

	@Generated
	@Owned
	@Selector("alloc")
	public static native IronSource alloc();

	@Generated
	@Selector("allocWithZone:")
	@MappedReturn(ObjCObjectMapper.class)
	public static native Object allocWithZone(VoidPtr zone);

	@Generated
	@Selector("automaticallyNotifiesObserversForKey:")
	public static native boolean automaticallyNotifiesObserversForKey(String key);

	@Generated
	@Selector("cancelPreviousPerformRequestsWithTarget:")
	public static native void cancelPreviousPerformRequestsWithTarget(
			@Mapped(ObjCObjectMapper.class) Object aTarget);

	@Generated
	@Selector("cancelPreviousPerformRequestsWithTarget:selector:object:")
	public static native void cancelPreviousPerformRequestsWithTargetSelectorObject(
			@Mapped(ObjCObjectMapper.class) Object aTarget, SEL aSelector,
			@Mapped(ObjCObjectMapper.class) Object anArgument);

	@Generated
	@Selector("classFallbacksForKeyedArchiver")
	public static native NSArray<String> classFallbacksForKeyedArchiver();

	@Generated
	@Selector("classForKeyedUnarchiver")
	public static native Class classForKeyedUnarchiver();

	@Generated
	@Selector("clearRewardedVideoServerParameters")
	public static native void clearRewardedVideoServerParameters();

	@Generated
	@Selector("debugDescription")
	public static native String debugDescription_static();

	@Generated
	@Selector("description")
	public static native String description_static();

	@Generated
	@Selector("destroyBanner:")
	public static native void destroyBanner(ISBannerView banner);

	@Generated
	@Selector("hasISDemandOnlyInterstitial:")
	public static native boolean hasISDemandOnlyInterstitial(String instanceId);

	@Generated
	@Selector("hasISDemandOnlyRewardedVideo:")
	public static native boolean hasISDemandOnlyRewardedVideo(String instanceId);

	@Generated
	@Selector("hasInterstitial")
	public static native boolean hasInterstitial();

	@Generated
	@Selector("hasOfferwall")
	public static native boolean hasOfferwall();

	@Generated
	@Selector("hasRewardedVideo")
	public static native boolean hasRewardedVideo();

	@Generated
	@Selector("hash")
	@NUInt
	public static native long hash_static();

	@Generated
	@Selector("init")
	public native IronSource init();

	@Generated
	@Selector("initISDemandOnly:adUnits:")
	public static native void initISDemandOnlyAdUnits(String appKey,
			NSArray<String> adUnits);

	@Generated
	@Selector("initWithAppKey:")
	public static native void initWithAppKey(String appKey);

	@Generated
	@Selector("initWithAppKey:adUnits:")
	public static native void initWithAppKeyAdUnits(String appKey,
			NSArray<String> adUnits);

	@Generated
	@Selector("instanceMethodForSelector:")
	@FunctionPtr(name = "call_instanceMethodForSelector_ret")
	public static native NSObject.Function_instanceMethodForSelector_ret instanceMethodForSelector(
			SEL aSelector);

	@Generated
	@Selector("instanceMethodSignatureForSelector:")
	public static native NSMethodSignature instanceMethodSignatureForSelector(
			SEL aSelector);

	@Generated
	@Selector("instancesRespondToSelector:")
	public static native boolean instancesRespondToSelector(SEL aSelector);

	@Generated
	@Selector("isBannerCappedForPlacement:")
	public static native boolean isBannerCappedForPlacement(String placementName);

	@Generated
	@Selector("isInterstitialCappedForPlacement:")
	public static native boolean isInterstitialCappedForPlacement(
			String placementName);

	@Generated
	@Selector("isRewardedVideoCappedForPlacement:")
	public static native boolean isRewardedVideoCappedForPlacement(
			String placementName);

	@Generated
	@Selector("isSubclassOfClass:")
	public static native boolean isSubclassOfClass(Class aClass);

	@Generated
	@Selector("keyPathsForValuesAffectingValueForKey:")
	public static native NSSet<String> keyPathsForValuesAffectingValueForKey(
			String key);

	@Generated
	@Selector("loadBannerWithViewController:size:")
	public static native void loadBannerWithViewControllerSize(
			UIViewController viewController, @NUInt long size);

	@Generated
	@Selector("loadBannerWithViewController:size:placement:")
	public static native void loadBannerWithViewControllerSizePlacement(
			UIViewController viewController, @NUInt long size,
			String placementName);

	@Generated
	@Selector("loadISDemandOnlyInterstitial:")
	public static native void loadISDemandOnlyInterstitial(String instanceId);

	@Generated
	@Selector("loadInterstitial")
	public static native void loadInterstitial();

	@Generated
	@Owned
	@Selector("new")
	@MappedReturn(ObjCObjectMapper.class)
	public static native Object new_objc();

	@Generated
	@Selector("offerwallCredits")
	public static native void offerwallCredits();

	@Generated
	@Selector("resolveClassMethod:")
	public static native boolean resolveClassMethod(SEL sel);

	@Generated
	@Selector("resolveInstanceMethod:")
	public static native boolean resolveInstanceMethod(SEL sel);

	@Generated
	@Selector("rewardedVideoPlacementInfo:")
	public static native ISPlacementInfo rewardedVideoPlacementInfo(
			String placementName);

	@Generated
	@Selector("sdkVersion")
	public static native String sdkVersion();

	@Generated
	@Selector("setAdaptersDebug:")
	public static native void setAdaptersDebug(boolean flag);

	@Generated
	@Selector("setAge:")
	public static native void setAge(@NInt long age);

	@Generated
	@Selector("setBannerDelegate:")
	public static native void setBannerDelegate(
			@Mapped(ObjCObjectMapper.class) ISBannerDelegate delegate);

	@Generated
	@Selector("setConsent:")
	public static native void setConsent(boolean consent);

	@Generated
	@Selector("setDynamicUserId:")
	public static native boolean setDynamicUserId(String dynamicUserId);

	@Generated
	@Selector("setGender:")
	public static native void setGender(@NInt long gender);

	@Generated
	@Selector("setISDemandOnlyInterstitialDelegate:")
	public static native void setISDemandOnlyInterstitialDelegate(
			@Mapped(ObjCObjectMapper.class) ISDemandOnlyInterstitialDelegate delegate);

	@Generated
	@Selector("setISDemandOnlyRewardedVideoDelegate:")
	public static native void setISDemandOnlyRewardedVideoDelegate(
			@Mapped(ObjCObjectMapper.class) ISDemandOnlyRewardedVideoDelegate delegate);

	@Generated
	@Selector("setInterstitialDelegate:")
	public static native void setInterstitialDelegate(
			@Mapped(ObjCObjectMapper.class) ISInterstitialDelegate delegate);

	@Generated
	@Selector("setLogDelegate:")
	public static native void setLogDelegate(
			@Mapped(ObjCObjectMapper.class) ISLogDelegate delegate);

	@Generated
	@Selector("setMediationSegment:")
	public static native void setMediationSegment(String segment);

	@Generated
	@Selector("setMediationType:")
	public static native void setMediationType(String mediationType);

	@Generated
	@Selector("setOfferwallDelegate:")
	public static native void setOfferwallDelegate(
			@Mapped(ObjCObjectMapper.class) ISOfferwallDelegate delegate);

	@Generated
	@Selector("setRewardedInterstitialDelegate:")
	public static native void setRewardedInterstitialDelegate(
			@Mapped(ObjCObjectMapper.class) ISRewardedInterstitialDelegate delegate);

	@Generated
	@Selector("setRewardedVideoDelegate:")
	public static native void setRewardedVideoDelegate(
			@Mapped(ObjCObjectMapper.class) ISRewardedVideoDelegate delegate);

	@Generated
	@Selector("setRewardedVideoServerParameters:")
	public static native void setRewardedVideoServerParameters(
			NSDictionary<?, ?> parameters);

	@Generated
	@Selector("setSegment:")
	public static native void setSegment(ISSegment segment);

	@Generated
	@Selector("setSegmentDelegate:")
	public static native void setSegmentDelegate(
			@Mapped(ObjCObjectMapper.class) ISSegmentDelegate delegate);

	@Generated
	@Selector("setUserId:")
	public static native void setUserId(String userId);

	@Generated
	@Selector("setVersion:")
	public static native void setVersion_static(@NInt long aVersion);

	@Generated
	@Selector("shouldTrackReachability:")
	public static native void shouldTrackReachability(boolean flag);

	@Generated
	@Selector("showISDemandOnlyInterstitial:instanceId:")
	public static native void showISDemandOnlyInterstitialInstanceId(
			UIViewController viewController, String instanceId);

	@Generated
	@Selector("showISDemandOnlyInterstitial:placement:instanceId:")
	public static native void showISDemandOnlyInterstitialPlacementInstanceId(
			UIViewController viewController, String placementName,
			String instanceId);

	@Generated
	@Selector("showISDemandOnlyRewardedVideo:instanceId:")
	public static native void showISDemandOnlyRewardedVideoInstanceId(
			UIViewController viewController, String instanceId);

	@Generated
	@Selector("showISDemandOnlyRewardedVideo:placement:instanceId:")
	public static native void showISDemandOnlyRewardedVideoPlacementInstanceId(
			UIViewController viewController, String placementName,
			String instanceId);

	@Generated
	@Selector("showInterstitialWithViewController:")
	public static native void showInterstitialWithViewController(
			UIViewController viewController);

	@Generated
	@Selector("showInterstitialWithViewController:placement:")
	public static native void showInterstitialWithViewControllerPlacement(
			UIViewController viewController, String placementName);

	@Generated
	@Selector("showOfferwallWithViewController:")
	public static native void showOfferwallWithViewController(
			UIViewController viewController);

	@Generated
	@Selector("showOfferwallWithViewController:placement:")
	public static native void showOfferwallWithViewControllerPlacement(
			UIViewController viewController, String placementName);

	@Generated
	@Selector("showRewardedVideoWithViewController:")
	public static native void showRewardedVideoWithViewController(
			UIViewController viewController);

	@Generated
	@Selector("showRewardedVideoWithViewController:placement:")
	public static native void showRewardedVideoWithViewControllerPlacement(
			UIViewController viewController, String placementName);

	@Generated
	@Selector("superclass")
	public static native Class superclass_static();

	@Generated
	@Selector("version")
	@NInt
	public static native long version_static();
}